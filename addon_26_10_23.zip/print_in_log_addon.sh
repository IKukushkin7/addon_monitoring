#!/usr/bin/with-contenv bashio
echo $1
